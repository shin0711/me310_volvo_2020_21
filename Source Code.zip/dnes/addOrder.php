<?php
    session_start();

    // Check if the user has logged in
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] === false){
        header("location: index.php");
        exit;
    }
    
    $userID = $_SESSION['userID'];
    $addDate = date('Y-m-d H:i:s');

    $sourcingCompany = $receivingCompany = $transportCompany = "";
    $sourcingSig = $receiveSig = $transportCo = $materialID = "";

    $formErr = "";
    $upload = true;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // ==================== Check Sourcing Form ============================ 
        if (empty($_POST["sourcingCompany"])) {
            $upload = false;
        } else {
            $sourcingCompany = htmlspecialchars($_POST['sourcingCompany']);
        }

        if (empty($_POST["materialID"])) {
            $upload = false;
        } else {
            $materialID = htmlspecialchars($_POST['materialID']);
        }

        if (empty($_POST["sourcingSignee"])) {
            $upload = false;
        } else {
            $sourcingSig= htmlspecialchars($_POST['sourcingSignee']);
        }

        // ==================== Check Receiving Form ============================ 
        if (empty($_POST["receivingCompany"])) {
            $upload = false;
        } else {
            $receivingCompany= htmlspecialchars($_POST['receivingCompany']);
        }

        if (empty($_POST["receiveSignee"])) {
            $upload = false;
        } else {
            $receiveSig = htmlspecialchars($_POST['receiveSignee']);
        }

        // ==================== Check Transport Form ============================ 
        if (empty($_POST["transportCompany"])) {
            $upload = false;
        } else {
            $transportCompany = htmlspecialchars($_POST['transportCompany']);
        }

        if (empty($_POST["transportCoordinator"])) {
            $upload = false;
        } else {
            $transportCo = htmlspecialchars($_POST['transportCoordinator']);
        }

        //upload data to the database
        if ($upload) {
            $orderID = uniqid("order");
            $orderStatus = "Initiated";
            include "PDO_connect.php";
            $insert_sql = "INSERT INTO orderinfo (orderID, materialID, sourcingCompany, receiveCompany, transportCompany, 
                                                  sourcingSignee, receiveSignee, transportCoordinator, addDate, initiatedBy, orderStatus)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?);";
            $stmt = $pdo->prepare($insert_sql);
            $stmt->bindParam(1, $orderID);
            $stmt->bindParam(2, $materialID);
            $stmt->bindParam(3, $sourcingCompany);
            $stmt->bindParam(4, $receivingCompany);
            $stmt->bindParam(5, $transportCompany);
            $stmt->bindParam(6, $sourcingSig);
            $stmt->bindParam(7, $receiveSig);
            $stmt->bindParam(8, $transportCo);
            $stmt->bindParam(9, $addDate);
            $stmt->bindParam(9, $addDate);
            $stmt->bindParam(10, $userID);
            $stmt->bindParam(11, $orderStatus);
            $stmt->execute();
            
            header("location: newOrder.php?orderID=". $orderID);
        } else {
            $formErr = "Form is not completed.";
        }
    }
?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> DNES - Register Order </title>

<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 
</head>
<body>
<!-- Main Container -->
<div class="container"> 
<!-- Navigation -->
  <header> 
    <nav2>
	    <a href="Home.php"> 
	        <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
		</a> 
	</nav2>  
    <nav>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	  <img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	  </div>
  
		<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>
	
  <section>
  <!-- Stats Gallery Section -->
	  <div class="gallery">
		<div class="thumbnail" onclick="document.location='addMaterial.php'">
		  <div class="button2">Add New Material </div>
		</div>
		  <div class="thumbnail" onclick="document.location='addOrder.php'">
		  <div class="button3">Add New Order </div>
		</div>
		   <div class="thumbnail" onclick="document.location='viewCurrentOrders.php'">
		  <div class="button2">View Current Orders </div>
		</div>
		<div class="thumbnail" onclick="document.location='viewPastOrders.php'">
		  <div class="button2">View Past Orders </div>
		</div>
	  </div>
</section>
  <!-- Parallax Section -->
  <section class="banner" style="height: auto">
    <h2 class="parallax" style="padding-top: 50px">Register A New Order</h2>
    <p class="parallax_description">
        <?php echo $_SESSION['userFullname'] ?> will be marked as this order's registrator for <?php echo $_SESSION['company'] ?>
    </p>
	<div class="banner2">
        
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data"
        style=" width: 70%; max-width: 500px; align-content: center;display: flex;flex-direction: column; padding-bottom: 50px">
            <span class="error">* <?php echo $formErr;?></span>
            
            <!-- ================================= Sourcing =====================================-->
            <h2 class="parallax" style="padding-top: 50px">Sourcing</h2>
            <select name="sourcingCompany" id='sourcingCompany' class="select__style" for="S_Co">
                <option disabled selected> -- Select Sourcing Company -- </option>
                <?php
                // Include database config file
                require_once "config.php";
                
                // search for employees within the same company
                $sql = "SELECT DISTINCT companyName FROM userinfo WHERE companyName IS NOT NULL";
                $result = $conn->query($sql);

                // show query result in a dropdown menu
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='". $row['companyName'] ."'>" .$row['companyName'] ."</option>";
                }
                ?>
            </select><br>
            
            <select name="materialID" id="materialID" class="select__style" for="mtrl">
                <option disabled selected> -- Select Material -- </option>
            </select><br>
            
            <select name="sourcingSignee" id="sourcingSignee" class="select__style" for="Signee1">
                <option disabled selected> -- Select Person on Site to Confirm Delivery -- </option>
            </select><br>
            
            <!-- ================================= Receiving =====================================-->
            <h2 class="parallax">Receiving</h2>
            <select name="receivingCompany" id='receivingCompany' class="select__style" for="S_Co">
                <option disabled selected> -- Select Receiving Company -- </option>
                <?php
                
                // search for employees within the same company
                $sql = "SELECT DISTINCT companyName FROM userinfo WHERE companyName IS NOT NULL";
                $result = $conn->query($sql);

                // show query result in a dropdown menu
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='". $row['companyName'] ."'>" .$row['companyName'] ."</option>";
                }
                ?>
            </select><br>

            <select name="receiveSignee" id='receivingSignee' class="select__style" for="mtrl">
                <option disabled selected> -- Select Person on Site to Accept Delivery -- </option>
            </select><br><br>
            
            <!-- ================================= Transporting =====================================-->
            <h2 class="parallax">Transporting</h2>
            <select name="transportCompany" id='transportCompany' class="select__style" for="S_Co">
                <option disabled selected> -- Select Transporting Company -- </option>
                <?php
                
                // search for employees within the same company
                $sql = "SELECT DISTINCT companyName FROM userinfo WHERE companyName IS NOT NULL";
                $result = $conn->query($sql);

                // show query result in a dropdown menu
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='". $row['companyName'] ."'>" .$row['companyName'] ."</option>";
                }
                ?>
            </select><br><br>

            <select name="transportCoordinator" id = 'transportCoordinator' class="select__style" for="S_Co">
                <option disabled selected> -- Select Transport Coordinator -- </option>
            </select><br><br>

        <br>
        <input type="submit" class="button2" value="Submit">
    </form>
	</div>
  </section>

 <!-- Footer Section -->
 <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>

<!-- Script for dependent dropdown list -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>
    // Dependent drop down for sourcing company
    $('#sourcingCompany').on('change', function(){
        var company = this.value;
        $.ajax({
            type: "POST",
            url: "materialsDropdown.php",
            data:'company=' + company,
            success: function(result) {
                $("#materialID").html(result);
            }
        });

        $.ajax({
            type: "POST",
            url: "usersDropdown.php?text=Select Person on Site to Confirm Delivery",
            data: 'company=' + company,
            success: function(result) {
                $("#sourcingSignee").html(result);
            }
        });
    });

    // Dependent drop down for receiving company
    $('#receivingCompany').on('change', function(){
        var company = this.value;
        $.ajax({
            type: "POST",
            url: "usersDropdown.php?text=Select Person on Site to Accept Delivery",
            data: 'company=' + company,
            success: function(result) {
                $("#receivingSignee").html(result);
            }
        });
    });

    // Dependent drop down for transport company
    $('#transportCompany').on('change', function(){
        var company = this.value;
        $.ajax({
            type: "POST",
            url: "usersDropdown.php?text=Select Transport Coordinator",
            data: 'company=' + company,
            success: function(result) {
                $("#transportCoordinator").html(result);
            }
        });
    });
</script>
<!-- Main Container Ends -->
</body>
</html>