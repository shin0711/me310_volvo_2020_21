<?php
    session_start();

    require_once "config.php";
    $materialID = isset($_GET['materialID'])? $_GET['materialID'] : "";
    
    // get the material info from database
    $sql = "SELECT * FROM materialinfo WHERE materialID = '$materialID'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $userID = $row['userID'];
    $materialName = $row['materialName'];
    $addDate = $row['addDate'];
    $labDataName = $row['labDataName'];
    $initiatorID = $row['initiatedBy'];

    // get the full name of the material registrator
    $sql = "SELECT * FROM userinfo WHERE userID = '$initiatorID'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $initiator = $row['fullname'];
    $company = $row['companyName'];

    $conn->close();
?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DNES - New Material Added</title>
<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 

</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> 
    <nav2>
		  <a href="Home.php"> 
	      <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
		  </a> 
	  </nav2>  
    <nav>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </nav>
  </header>
  
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	  <img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	  </div>
  
		<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>

  <!-- Stats Gallery Section -->
  <section>
    <div class="gallery">
		<div class="thumbnail" onclick="document.location='addMaterial.php'">
		  <div class="button2">Add New Material </div>
		</div>
		  <div class="thumbnail" onclick="document.location='addOrder.php'">
		  <div class="button2">Add New Order </div>
		</div>
		   <div class="thumbnail" onclick="document.location='viewCurrentOrders.php'">
		  <div class="button2">View Current Orders </div>
		</div>
		<div class="thumbnail" onclick="document.location='viewPastOrders.php'">
		  <div class="button2">View Past Orders </div>
		</div>
	  </div>
</section>

  <!-- Parallax Section -->
  <section class="banner">
    <h2 class="parallax">Congrats! <?php echo $materialName;?> has been registered</h2>
	<p class="parallax_description">
		<?php echo $materialName;?> is associated with <?php echo $company;?>
		on <?php echo $addDate;?> by <?php echo $initiator;?> <br> <br> <br>
        Material ID: <?php echo $materialID; ?><br><br>
        Material Name: <?php echo $materialName; ?><br><br>
        Lab Report: <?php echo "<li><a href='viewLabReport.php?id=".$materialID."'>".$labDataName."</a></li>" ?> <br><br>
	</p><br>
  </section>

  <!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>
