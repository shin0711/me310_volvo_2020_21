<?php
require_once "config.php";

$materialID = isset($_GET['id'])? $_GET['id'] : "";

$sql = "SELECT * FROM materialinfo WHERE materialID = '$materialID'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$labDataType = $row['labDataType'];
$labDataBig = $row['labDataBig'];

header('Content-Type:'.$labDataType);
header('Content-Disposition: inline; filename=.pdf');
header('Content-Transfer-Encoding: binary');
header('Accept-Ranges: bytes');

echo $labDataBig;

$conn->close();
?>