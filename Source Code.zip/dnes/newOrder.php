<?php
    session_start();

    require_once "config.php";
    $orderID = isset($_GET['orderID'])? $_GET['orderID'] : "";

    $sql = "SELECT * FROM orderinfo WHERE orderID = '$orderID'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $materialID = $row['materialID'];
    $sourcingCompany = $row['sourcingCompany'];
    $receiveCompany = $row['receiveCompany'];
    $transportCompany = $row['transportCompany'];
    $sourcingSignee = $row['sourcingSignee'];
    $receiveSignee = $row['receiveSignee'];
    $transportCoordinator = $row['transportCoordinator'];
    $addDate = $row['addDate'];
    $initiatorID = $row['initiatedBy'];

    $sql = "SELECT * FROM userinfo WHERE userID = '$initiatorID'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $initiator = $row['fullname'];

    $sql = "SELECT * FROM materialinfo WHERE materialID = '$materialID'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $materialName = $row['materialName'];

    $conn->close();
?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DNES - Order Success</title>

<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> 
    <nav2>
		  <a href="Home.php"> 
	      <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
		  </a> 
	  </nav2>  
    <nav>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	  <img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	  </div>
  
		<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>
	
  <section>
  <!-- Stats Gallery Section -->
  <div class="gallery">
		<div class="thumbnail" onclick="document.location='addMaterial.php'">
		  <div class="button2">Add New Material </div>
		</div>
		  <div class="thumbnail" onclick="document.location='addOrder.php'">
		  <div class="button2">Add New Order </div>
		</div>
		   <div class="thumbnail" onclick="document.location='viewCurrentOrders.php'">
		  <div class="button2">View Current Orders </div>
		</div>
		<div class="thumbnail" onclick="document.location='viewPastOrders.php'">
		  <div class="button2">View Past Orders </div>
		</div>
	  </div>
</section>
  <!-- Parallax Section -->
  <section class="banner">
    <h2 class="parallax">Congrats! Order <?php echo $orderID?> has been registered</h2>
	<p class="parallax_description">
	  <?php echo $materialName ?> will be delivered from <?php echo $sourcingCompany;?>
	  to <?php echo $receiveCompany;?> by <?php echo $transportCompany;?>.</p>
	<p class= "parallax_description">
	  This order is created on <?php echo $addDate;?> by <?php echo $initiator ?></p>
  </section>

   <!-- Footer Section -->
   <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>