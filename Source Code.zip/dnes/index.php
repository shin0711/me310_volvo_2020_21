<?php
// Initialize the session
session_start();
 
// // Check if the user is already logged in, if yes then redirect him to welcome page
// if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
//     header("location: Home.php");
//     exit;
// }

$_SESSION["loggedin"] = false;
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $login_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
		if(empty($login_err)){
        	$login_err = "Please enter your password.";
		}
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($login_err)){
        // Prepare a select statement
        $sql = "SELECT * FROM userinfo WHERE username LIKE '$username'";
  		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			$password_db = $row["password"];
			if ($password == $password_db) {
				// Password is correct, so start a new session
				session_start();
                            
				// Store data in session variables
				$_SESSION["loggedin"] = true;
				$_SESSION["username"] = $username;                            
				
				// Redirect user to welcome page
				header("location: Home.php");
			} else {
				$login_err = "Invalid username or password, please try again";
			}
		} else {
			$login_err = "Invalid username or password, please try again";
		}  
    }
    
    // Close connection
    $conn->close();
}
?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DNES - Login</title>
	
<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 

</head>	
	
<body>
<!-- Main Container -->
<div class="container"> 
<!-- Navigation -->
<header> 
	<nav2>
	   <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
	</nav2>   
    <nav>
      <ul>
        <li><a href="index.php">LOGIN</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	<img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	</div>
  
	<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>

  	<!-- Parallax Section -->
	<section>
		<div class="multiple_items_V" height="auto">
		<h2>Login</h2>
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
						
				<input type="text" id="fname" placeholder="Name" class="form__input2 form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" name="username"><label class="form__label2" for="fname">Name</label><br>
					
				<input type="password" id="psswrd" placeholder="Password" class="form__input2 form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" name="password"><label class="form__label2" for="psswrd">Password</label><br>
					
				<input type="submit" class="button2" value="Login">

					
				</form>
		  <p> <span class="invalid-feedback"><?php echo $login_err; ?></span></p>
	  </div>
	</section>
	<div class= "multiple_items_H" 	style="background-color:#FFFFFF">
	 <div class="multiple_items_V">
		 <object data="images/First Step.svg" width=auto height="500px"></object>
		 <h2> Step One : Sourcing Site</h2>
		 <h3> Have Surplus or Raw Material? Log Material Information on DNES</h3>
	</div>
	
	<div class="multiple_items_V">
		 <object data="images/Second Step.svg" width=auto height="500px"></object>
		 <h2>Step Two : Collecting</h2>
		 <h3 >Begin live data collection with photo authentication</h3>
	</div>
	
	 <div class="multiple_items_V">
		 <object data="images/Third Step.svg" width=auto height="600px"></object>
		 <h2 style="text-align:center">Step Three : Sending</h2>
		 <h3 style="text-align:center">Go paperless with secure delivery sign-offs</h3>
	</div>
	
	 <div class="multiple_items_V">
		 <object data="images/Fourth Step.svg" width=auto height="600px"></object>
		 <h2 style="text-align:center">Step Four : Transportation</h2>
		 <h3 style="text-align:center">Scalable with multiple loads per material order</h3>
	</div>
	
	 <div class="multiple_items_V">
	 	 <object data="images/Fifth Step.svg" width=auto height="600px"></object>
		 <h2 style="text-align:center">Step Five : Recieving Site</h2>
		 <h3 style="text-align:center">Accept each load digitally with ease and assurance</h3>
	</div>
	
	 <div class="multiple_items_V">
		 
		 <object data="images/Sixth Step.svg" width=auto height="600px"></object>

		 <h2 style="text-align:center">Throughout:</h2>
		 <h3 2 style="text-align:center;max-width: 70%">Data is automatically shared digitally to all companies of the order creating a transparent and trustworthy collaboration space</h3>
	</div>
</div>
	
  <!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>


