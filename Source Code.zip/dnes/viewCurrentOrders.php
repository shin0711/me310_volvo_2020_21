<?php
  session_start();
  
  // Check if the user has logged in
  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] === false){
    header("location: index.php");
    exit;
  }

  require_once "config.php";

  $username = $_SESSION["username"];

  // fetch data corresponding to the username from database
  $sql = "SELECT * FROM userinfo WHERE username = '$username'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  $userCompany = $row["companyName"];

?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> DNES - Current Orders </title>

<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> 
    <nav2>
		  <a href="Home.php"> 
	      <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
		  </a> 
	  </nav2>  
    <nav>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	  <img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	  </div>
  
		<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>
	
  <section>
  <!-- Stats Gallery Section -->
	  <div class="gallery">
		<div class="thumbnail" onclick="document.location='addMaterial.php'">
		  <div class="button2">Add New Material </div>
		</div>
		  <div class="thumbnail" onclick="document.location='addOrder.php'">
		  <div class="button2">Add New Order </div>
		</div>
		   <div class="thumbnail" onclick="document.location='viewCurrentOrders.php'">
		  <div class="button3">View Current Orders </div>
		</div>
		<div class="thumbnail" onclick="document.location='viewPastOrders.php'">
		  <div class="button2">View Past Orders </div>
		</div>
	  </div>
</section>
  <!-- Parallax Section -->
  <section class="banner2">
    <h2 class="parallax" style="padding-top: 100px">Current Orders for <?php echo $userCompany ?></h2>
    <br>
    <table>
      <tr>
        <th><strong>Order ID</strong></th>
        <th><strong>Material Name</strong></th>
        <th><strong>Status</strong></th>
        <th><strong>Date Started</strong></th>
        <th><strong>View Details</strong></th>
      </tr> 
      <?php
          // search for employees within the same company
          $sql = "SELECT * FROM orderinfo WHERE orderStatus != 'Completed' AND (sourcingCompany = '$userCompany' OR receiveCompany = '$userCompany' OR transportCompany = '$userCompany')";
          $result = $conn->query($sql);

          // show query result in a dropdown menu
          while ($row = $result->fetch_assoc()) {
            $orderID = $row['orderID'];
            $materialID = $row['materialID'];
            $addDate = $row['addDate'];
            $linkURL = "orderReview.php?orderID=". $orderID;
            $orderStatus = $row['orderStatus'];
            
            $sql_m = "SELECT * FROM materialinfo WHERE materialID = '$materialID'";
            $result_m = $conn->query($sql_m);
            $row_m = $result_m->fetch_assoc();
            $materialName = $row_m['materialName'];

            if ($orderStatus != "Completed") {
              echo "<tr>";
              echo "<th>". $orderID . "</th><th>". $materialName. "</th><th>". $orderStatus. 
                   "</th><th>". $addDate. "</th><th>";
              echo "<div class='buttonsmall' onclick=\"document.location='". $linkURL ."'\">More</div>";
              echo "</th>";
              echo "</tr>";
            }
          }
          $conn->close();
      ?>
    </table>
  </section>

 <!-- Footer Section -->
 <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>