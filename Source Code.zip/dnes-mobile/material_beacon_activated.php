<?php
    $materialID = isset($_GET['materialID'])? $_GET['materialID'] : "";
    $beaconID = isset($_GET['beaconID'])? $_GET['beaconID'] : "";

    require_once "PDO_connect.php";
    $query = $pdo->prepare("SELECT * FROM materialinfo WHERE materialID = '$materialID'");
    $query->execute();
    $row = $query->fetch();
    $materialName = $row["materialName"];
?>

<!doctype html>
<html>
<head>
	<link href="css/mobile.css" rel="stylesheet" type="text/css">
	<meta charset="utf-8">
	<title>DNES Mobile - Material Beacon Activated</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- For Font -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
	
	<script> // For Mobile
	// First we get the viewport height and we multiple it by 1% to get a value for a vh unit
	let vh = window.innerHeight * 0.01;
	// Then we set the value in the --vh custom property to the root of the document
	document.documentElement.style.setProperty('--vh', `${vh}px`);

	// We listen to the resize event
	window.addEventListener('resize', () => {
	  // We execute the same script as before
	  let vh = window.innerHeight * 0.01;
	  document.documentElement.style.setProperty('--vh', `${vh}px`);
	});
	</script>
</head>	
	
<body>
	<div class="module">
	<a href="Home.php">
	<header>	
		<img src="images/circle_logo.svg" alt= "DNES logo" style="height:80%"/>
   </header>
	</a>

	<div class="multiple_items_V" style="height: 90%">
		<h2>Success!</h2>
				 
<!-- if sucessful, then show checkmark and redirect -->
	<img src="images/check.svg" alt= "success_check" style="height:20%"/>
	<p align="center"> Added Beacon <?php echo $beaconID ?> to <?php echo $materialName. " (". $materialID. ")" ?> </p>
	
<!-- if we want to redirect home in 3 seconds -----------------------
	<script>
	//Using setTimeout to execute a function after 3 seconds.
	setTimeout(function () {
	   //Redirect with JavaScript
	   window.location.href= 'Home.php';
	}, 3000);
	</script> -->

	</div>
		
		
	<div class="footer">&copy;2021 thednes.com</div>
	</div>
</body>
</html>