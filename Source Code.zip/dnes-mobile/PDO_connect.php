<?php
  // Database credentials (LOCAL)
  $dbServer = "localhost";
  $dbUsername = "root";
  $dbPassword = "";
  $dbName = "me310_teamvolvo";

  // Database credentials (HEROKU)
  if (getenv('DB_HOST', true)) {
    $dbServer = getenv('DB_HOST');
    $dbUsername = getenv('DB_USERNAME');
    $dbPassword = getenv('DB_PASSWORD');
    $dbName = getenv('DB_NAME');
  }

  $pdo = new PDO("mysql:host=$dbServer;dbname=$dbName", $dbUsername, $dbPassword);

?>