<?php
	session_start();

	// Include config file
	require_once "config.php";
 
	// Define variables and initialize with empty values
	$username = $password = "";
	$username_err = $password_err = $login_err = "";
 
	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
 
		// Check if username is empty
		if(empty(trim($_POST["username"]))){
			$login_err = "Please enter username.";
		} else{
			$username = trim($_POST["username"]);
		}
    
		// Check if password is empty
		if(empty(trim($_POST["password"]))){
			if (empty($login_err)) {
				$login_err = "Please enter your password.";
			}
		} else{
			$password = trim($_POST["password"]);
		}
    
		// Validate credentials
		if(empty($login_err)){
			// Prepare a select statement
			$sql = "SELECT * FROM userinfo WHERE username LIKE '$username'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();
				$password_db = $row["password"];
				if ($password == $password_db) {
					// Password is correct, so start a new session
					// session_start();
								
					// Store data in session variables
					$_SESSION["loggedin"] = true;
					$_SESSION["username"] = $username;
					$_SESSION["userID"] = $row["userID"];                
					
					// Redirect user to welcome page
					header("location: Home.php");
				} else {
					$login_err = "Incorrect username or password, please try again";
				}
			} else {
				$login_err = "Incorrect username or password, please try again";
			}  
		}
	}

	// Close connection
    $conn->close();
?>

<!doctype html>
<html>
<head>
	<link href="css/mobile.css" rel="stylesheet" type="text/css">
	<link rel="icon" 
	<meta charset="utf-8">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="DNES">
	
	<title>DNES</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 
	
	<script> // For Mobile
		// First we get the viewport height and we multiple it by 1% to get a value for a vh unit
		let vh = window.innerHeight * 0.01;
		// Then we set the value in the --vh custom property to the root of the document
		document.documentElement.style.setProperty('--vh', `${vh}px`);

		// We listen to the resize event
		window.addEventListener('resize', () => {
		// We execute the same script as before
		let vh = window.innerHeight * 0.01;
		document.documentElement.style.setProperty('--vh', `${vh}px`);
		});
	</script>
	
	<!-- favicon code -->
	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="images/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/apple-touch-icon-144x144.png" />
	<link rel="apple-touch-icon-precomposed" sizes="60x60" href="images/apple-touch-icon-60x60.png" />
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="images/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon-precomposed" sizes="76x76" href="images/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon-precomposed" sizes="152x152" href="images/apple-touch-icon-152x152.png" />
	<link rel="icon" type="image/png" href="images/favicon-196x196.png" sizes="196x196" />
	<link rel="icon" type="image/png" href="images/favicon-96x96.png" sizes="96x96" />
	<link rel="icon" type="image/png" href="images/favicon-32x32.png" sizes="32x32" />
	<link rel="icon" type="image/png" href="images/favicon-16x16.png" sizes="16x16" />
	<link rel="icon" type="image/png" href="images/favicon-128.png" sizes="128x128" />
	<meta name="application-name" content="&nbsp;"/>
	<meta name="msapplication-TileColor" content="#52bad5" />
	<meta name="msapplication-TileImage" content="images/mstile-144x144.png" />
	<meta name="msapplication-square70x70logo" content="images/mstile-70x70.png" />
	<meta name="msapplication-square150x150logo" content="images/mstile-150x150.png" />
	<meta name="msapplication-wide310x150logo" content="images/mstile-310x150.png" />
	<meta name="msapplication-square310x310logo" content="images/mstile-310x310.png" />

	
</head>	
	
<body>
	<div class="module">
	<header>	
		<img src="images/circle_logo.svg" alt= "DNES logo" height="80%"/>
   </header>

	<div style="min-height: 90%; height: auto">
		<div class="mainblock">	
			
		<h2>Login</h2>
				<form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="width: 90%;">
					
					
				  <input type="text" id="fname" placeholder="Name" class="form__input form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" name="username"><label class="form__label" for="fname">Name</label><br>
					
				  <input type="text" id="psswrd" placeholder="Password" class="form__input form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" name="password"><label class="form__label" for="psswrd">Password</label><br>
					
				  <input type="submit" class="mobile_button" value="Login">
				</form>
				<p><?php echo $login_err; ?></p>
		  <!-- <p> Incorrect username or password, please try again</p> -->
		</div>
		
	  </div>

	<div class="footer">&copy;2021 thednes.com</div>
	</div>
</body>
</html>