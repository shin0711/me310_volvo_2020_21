<?php
    session_start();
    $beaconID = "";
    $error_msg = "";
    $materialID = isset($_GET['materialID'])? $_GET['materialID'] : "";
    $dateTime = date('Y-m-d H:i:s');
    $authenticate = true;

    // ini_set('post_max_size', '200M');
    // ini_set('upload_max_filesize', '10M');

    require "PDO_connect.php";  
    require "imageHelper.php";

    $query = $pdo->prepare("SELECT * FROM materialinfo WHERE materialID = '$materialID'");
    $query->execute();
    
    if ($row = $query->fetch()) {
        $materialName = $row["materialName"];
    }
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        // beacon ID is not entered
        if (empty($_POST["beaconID"])) {
            $error_msg = "Beacon ID is required";
            $authenticate = false;
        
        // beacon ID is entered
        } else {
            $beaconID = htmlspecialchars($_POST['beaconID']);
            
            // get the latest status of the beacon from the database
            $query = $pdo->prepare("SELECT * FROM beaconinfo WHERE beaconID = '$beaconID' ORDER BY pingTime DESC LIMIT 1");
            $query->execute();
            
            if ($row = $query->fetch()) {
                // the beacon is in Standby mode
                if ($row['beaconStatus'] == 'Standby') {
                    $beaconLat = $row['geoLat'];
                    $beaconLong = $row['geoLong'];
                } else {
                    $error_msg = "This beacon is in use";
                    $authenticate = false;
                }
            } else {
                $error_msg = "This beacon is not registered";
                $authenticate = false;
            }
        }

        // material photo is not uploaded
        if (empty($_FILES['materialPhoto']['tmp_name'])) {
            if (empty($error_msg)) {
                $error_msg = "Failed to upload the photo, please try again";
            }
            $authenticate = false;
        } else {
            $photo_name = $_FILES['materialPhoto']['name'];
            $photo_type = $_FILES['materialPhoto']['type'];
            $photo_data = $_FILES['materialPhoto']['tmp_name'];
            $photo_blob = file_get_contents($photo_data);

            // Get geolocation from the metadata of the photo
            if ($photoLocation = get_image_location($photo_data)) {
                $photoLat = $photoLocation['latitude'];
                $photoLong = $photoLocation['longitude'];
            
            // geolocation is not in the metadata
            } else {
                $error_msg = "Failed to get geolocation from photo, please try again";
                $authenticate = false;
            }
        }

        if ($authenticate) {
            $distance = distance($beaconLat, $beaconLong, $photoLat, $photoLong);
            
            // if the distance between the beacon and the photo is greater than 100ft
            if ($distance > 100) {
                $error_msg = "You did not take the picture close enough to the beacon, try again". $distance;
            } else {
                // save the data associated with the material into the database
                $beaconStatus = "Onsite";
                $insert_sql = "INSERT INTO beaconinfo (beaconID, materialID, beaconStatus, pingTime, 
                                                       geoLat, geoLong, materialPhoto, materialPhotoType)
                               VALUES(?,?,?,?,?,?,?,?)";
                $stmt = $pdo->prepare($insert_sql);
                $stmt->bindParam(1, $beaconID);
                $stmt->bindParam(2, $materialID);
                $stmt->bindParam(3, $beaconStatus);
                $stmt->bindParam(4, $dateTime);
                $stmt->bindParam(5, $beaconLat);
                $stmt->bindParam(6, $beaconLong);
                $stmt->bindParam(7, $photo_blob);
                $stmt->bindParam(8, $photo_type);
                $stmt->execute();

                // update the status of the material in the materialinfo table
                $update_sql = $pdo->prepare("UPDATE materialinfo SET isActivated = 1
                                             WHERE materialID = '$materialID'");
                $update_sql->execute();

                // session_start();
                header("location: material_beacon_activated.php?materialID=". $materialID. "&beaconID=". $beaconID);
            }
        }
    }
?>

<!doctype html>
<html>
<head>
	<link href="css/mobile.css" rel="stylesheet" type="text/css">
	<meta charset="utf-8">
	<title>DNES Mobile - Activate Beacon Onsite</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- For Font -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet">
	
	<script> // For Mobile
	// First we get the viewport height and we multiple it by 1% to get a value for a vh unit
	let vh = window.innerHeight * 0.01;
	// Then we set the value in the --vh custom property to the root of the document
	document.documentElement.style.setProperty('--vh', `${vh}px`);

	// We listen to the resize event
	window.addEventListener('resize', () => {
	  // We execute the same script as before
	  let vh = window.innerHeight * 0.01;
	  document.documentElement.style.setProperty('--vh', `${vh}px`);
	});
	</script>
</head>	
	
<body>
	<div class="module">
	<a href="Home.php">
	<header>	
		<img src="images/circle_logo.svg" alt= "DNES logo" style="height:80%"/>
   </header>
	</a>

	<div class="multiple_items_V"  style="height: auto">
		<h2>Start Tracking <?php echo $materialName; ?></h2>
		
		<form style="width:90%" method="post" enctype="multipart/form-data"
            action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]). "?materialID=". $materialID ;?>" >
            <div class="mainblock">	
			
			
			<input id="beacon_id_scan" type="text" name="beaconID" value="<?php echo $beaconID;?>" placeholder="Enter Beacon ID" class="form__input"><label class="form__label" for="bID">Enter beacon ID</label><br>
				
			<p style="text-align: center">Take a photo of the material with the beacon</p>
			<input id="photo-upload" name="materialPhoto" type="file" class="hidden" accept="image/*" capture="camera"/>
			<label for="photo-upload" class="mobile_button" style="font-weight: 500; letter-spacing: 1px"><img src="images/camera.svg" alt="Camera Icon" style="height:70px" /></label>
			<br>	
				
            <!-- <p> Beacon ID invalid or is in use for another material or order, try again</p> -->
            <p> <span class="error"><?php echo $error_msg;?></span> </P>
		    <!-- <p> You did not take the picture close enough to the beacon, try again</p> -->
			<input type="submit" class="mobile_button" value="Activate Material">
			</div>

		</form>
          <br>
		  
		
	</div>

	<div class="footer">&copy;2021 thednes.com</div>
	</div>
</body>
</html>